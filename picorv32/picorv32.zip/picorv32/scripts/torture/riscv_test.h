#ifndef RISCV_TEST_H
#define RISCV_TEST_H

#define RVTEST_RV32U
#define RVTEST_CODE_BEGIN
#define RVTEST_CODE_END
#define RVTEST_DATA_BEGIN
#define RVTEST_DATA_END

#define RVTEST_FAIL ebreak
#define RVTEST_PASS ebreak

#endif
